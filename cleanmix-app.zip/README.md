# CleanMix Distribuidora

Aplicativo/site catálogo da CleanMix Distribuidora.

## Como usar
1. Abra `index.html` no navegador para testar.
2. Edite os produtos no arquivo `app.js`.
3. Para publicar, envie estes arquivos para um repositório no GitHub e ative o GitHub Pages.

## WhatsApp
O botão de pedido está configurado para o número informado para a CleanMix: (91) 99160-3634.

## Próximos recursos
- Fotos reais dos produtos
- Painel administrativo
- Estoque
- Login
- Pagamento online
- Banco de dados
