const products=[
 {id:1,name:"Sabão Líquido",price:15.00,emoji:"🧴",desc:"Produto para limpeza geral."},
 {id:2,name:"Desinfetante",price:12.00,emoji:"🧼",desc:"Limpeza e perfumação de ambientes."},
 {id:3,name:"Sabão Líquido Automotivo",price:18.00,emoji:"🚗",desc:"Para lavagem de veículos."},
 {id:4,name:"Desengordurante",price:16.00,emoji:"✨",desc:"Ideal para sujeiras e gorduras."}
];
let cart=[];

function money(v){return v.toLocaleString("pt-BR",{minimumFractionDigits:2,maximumFractionDigits:2})}
function renderProducts(){
 const q=document.getElementById("search").value.toLowerCase();
 const list=products.filter(p=>p.name.toLowerCase().includes(q));
 document.getElementById("products").innerHTML=list.map(p=>`
  <article class="card">
   <div class="photo">${p.emoji}</div>
   <h3>${p.name}</h3><p>${p.desc}</p>
   <div class="price">R$ ${money(p.price)}</div>
   <button class="add" onclick="addToCart(${p.id})">Adicionar ao carrinho</button>
  </article>`).join("");
}
function addToCart(id){cart.push(products.find(p=>p.id===id));updateCart();openCart()}
function updateCart(){
 document.getElementById("cartCount").textContent=cart.length;
 document.getElementById("cartItems").innerHTML=cart.length?cart.map((p,i)=>`
 <div class="cart-row"><span>${p.name}</span><strong>R$ ${money(p.price)}</strong><button onclick="removeItem(${i})">✕</button></div>`).join(""):"<p>Seu carrinho está vazio.</p>";
 document.getElementById("cartTotal").textContent=money(cart.reduce((s,p)=>s+p.price,0));
}
function removeItem(i){cart.splice(i,1);updateCart()}
function openCart(){document.getElementById("cart").classList.remove("hidden");updateCart()}
function closeCart(){document.getElementById("cart").classList.add("hidden")}
function checkout(){
 if(!cart.length)return alert("Adicione pelo menos um produto.");
 const total=cart.reduce((s,p)=>s+p.price,0);
 const items=cart.map(p=>`• ${p.name} - R$ ${money(p.price)}`).join("\n");
 const msg=`Olá, CleanMix! Gostaria de fazer um pedido:\n\n${items}\n\nTotal: R$ ${money(total)}`;
 window.open("https://wa.me/5591991603634?text="+encodeURIComponent(msg),"_blank");
}
renderProducts();updateCart();